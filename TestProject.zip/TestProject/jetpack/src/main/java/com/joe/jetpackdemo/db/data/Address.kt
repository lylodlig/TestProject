package com.joe.jetpackdemo.db.data

/**
 * 地址
 */
data class Address(
    val street:String,val state:String,val city:String,val postCode:String
)