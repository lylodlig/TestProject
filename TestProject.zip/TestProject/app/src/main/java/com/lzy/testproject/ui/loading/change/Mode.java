package com.lzy.testproject.ui.loading.change;

/**
 * Created by leeiides on 2017/6/23.
 */

public enum Mode {
    REPLACE, COVER
}
