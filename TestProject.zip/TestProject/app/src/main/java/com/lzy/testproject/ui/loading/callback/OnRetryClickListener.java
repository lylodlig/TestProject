package com.lzy.testproject.ui.loading.callback;

import androidx.annotation.NonNull;
import android.view.View;

/**
 * 重试
 */

public interface OnRetryClickListener {
    void onRetry(@NonNull View view);
}
