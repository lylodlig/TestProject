package com.lzy.testproject.ui.softinput

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.lzy.testproject.R

class SoftInputActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_soft_input)
    }
}
