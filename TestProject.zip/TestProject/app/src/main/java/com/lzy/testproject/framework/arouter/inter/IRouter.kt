package com.lzy.testproject.framework.arouter.inter

/**
 * Created by LiZhiyu on 2018/8/23.
 */
interface IRouter {

    fun name()
}