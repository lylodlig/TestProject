package com.lzy.testproject.ui.recyclerview

import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * Created by LiZhiyu on 2018/7/9.
 */
class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
}