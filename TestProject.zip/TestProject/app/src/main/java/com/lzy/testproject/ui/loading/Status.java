package com.lzy.testproject.ui.loading;

/**
 * Created by dgg on 2017/11/7.
 */

public enum Status {
	NORMAL, LOADING, EMPTY, ERROR, NETWORK, CUSTOM
}
