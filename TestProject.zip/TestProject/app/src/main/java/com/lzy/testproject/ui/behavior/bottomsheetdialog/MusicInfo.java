package com.lzy.testproject.ui.behavior.bottomsheetdialog;

/**
 * Created by zhouwei on 16/12/2.
 */

public class MusicInfo {
    public String name;
    public String singer;

    public MusicInfo(){}

    public MusicInfo(String name, String singer) {
        this.name = name;
        this.singer = singer;
    }
}
