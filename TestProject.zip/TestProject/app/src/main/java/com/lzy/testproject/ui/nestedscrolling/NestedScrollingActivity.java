package com.lzy.testproject.ui.nestedscrolling;

import android.app.Activity;
import android.os.Bundle;

import com.lzy.testproject.R;

public class NestedScrollingActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nested_scrolling);
    }
}
