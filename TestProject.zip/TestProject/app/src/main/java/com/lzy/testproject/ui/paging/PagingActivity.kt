package com.lzy.testproject.ui.paging

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.lzy.testproject.R

class PagingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_paging)
    }
}
