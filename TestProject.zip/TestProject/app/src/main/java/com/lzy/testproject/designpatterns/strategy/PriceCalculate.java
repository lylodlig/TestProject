package com.lzy.testproject.designpatterns.strategy;

/**
 * Created by LiZhiyu on 2018/5/30.
 */
public interface PriceCalculate {
    /**
     * 返回电影价格
     * @return
     */
    int caculate();
}
