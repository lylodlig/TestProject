package com.lzy.testproject.ui.paging

/**
 * Created by LiZhiyu on 2018/7/9.
 */
class Student(var id:Int) {
}