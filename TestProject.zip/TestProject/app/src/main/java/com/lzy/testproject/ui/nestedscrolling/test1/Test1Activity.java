package com.lzy.testproject.ui.nestedscrolling.test1;

import android.app.Activity;
import android.os.Bundle;

import com.lzy.testproject.R;

public class Test1Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test1);
    }
}
