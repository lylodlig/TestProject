## 静态变量
通过companion object声明

## 延迟初始化