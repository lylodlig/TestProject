package com.lzy.testproject.framework.retrofit.entity

/**
 * Created by LiZhiyu on 2018/8/1.
 */
class Reception {
}